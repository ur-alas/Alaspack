StartupEvents.registry('item', event => {
   event.create('crushed_raw_yttrium').displayName('Crushed Raw Yttrium'); //using osmium texture
   event.create('yttrium_rod').displayName('Yttrium Rod'); //needs texture
   event.create('yttrium_plate').displayName('Yttrium Plate'); //needs texture


});
